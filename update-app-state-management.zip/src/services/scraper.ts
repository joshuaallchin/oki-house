// Scraper service to fetch live data from Okinoshima akiya bank
import { Property } from '../data/properties';

const BASE_URL = 'https://www.town.okinoshima.shimane.jp';
const LISTING_URL = `${BASE_URL}/cgi-bin/recruit.php/1/list`;

// CORS proxies - we'll try multiple in case one fails
// Note: Free proxies can be unreliable - we try several
const CORS_PROXIES = [
  // allorigins - returns JSON with contents field
  (url: string) => `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`,
  // killcors - newer proxy, no rate limits
  (url: string) => `https://proxy.killcors.com/?url=${encodeURIComponent(url)}`,
  // codetabs
  (url: string) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(url)}`,
  // corsproxy.io (may have localhost restriction)
  (url: string) => `https://corsproxy.io/?${encodeURIComponent(url)}`,
  // thingproxy
  (url: string) => `https://thingproxy.freeboard.io/fetch/${url}`,
];

// District coordinates (approximate centers for geocoding fallback)
const DISTRICT_COORDS: Record<string, { lat: number; lng: number }> = {
  '西郷地区（南部）': { lat: 36.2085, lng: 133.3260 },
  '西郷地区（北部）': { lat: 36.2280, lng: 133.3120 },
  '西郷地区（西部）': { lat: 36.1850, lng: 133.2620 },
  '西郷地区（東部）': { lat: 36.2150, lng: 133.3400 },
  '五箇地区': { lat: 36.2400, lng: 133.2000 },
  '都万地区': { lat: 36.1680, lng: 133.2800 },
  '布施地区': { lat: 36.2600, lng: 133.2700 },
  '中村地区': { lat: 36.2100, lng: 133.2400 },
};

// Location-specific coordinate offsets for variety
const LOCATION_OFFSETS: Record<string, { lat: number; lng: number }> = {
  '西町': { lat: 0.002, lng: -0.002 },
  '東町': { lat: -0.001, lng: 0.003 },
  '港町': { lat: -0.002, lng: -0.001 },
  '栄町': { lat: -0.003, lng: 0.004 },
  '中町': { lat: 0.001, lng: 0.001 },
  '有木': { lat: 0.003, lng: -0.003 },
  '今津': { lat: 0.002, lng: 0.002 },
  '都万': { lat: 0.001, lng: 0.002 },
  '久見': { lat: 0.005, lng: -0.010 },
  '津戸': { lat: -0.004, lng: -0.003 },
  '池田': { lat: 0.002, lng: -0.001 },
  '平': { lat: 0.004, lng: -0.002 },
  '郡': { lat: -0.002, lng: 0.005 },
  '岬町': { lat: 0.003, lng: -0.005 },
  '城北町': { lat: 0.004, lng: 0.003 },
  '原田': { lat: 0.006, lng: -0.004 },
  '下西': { lat: -0.005, lng: 0.001 },
  '加茂': { lat: -0.006, lng: -0.008 },
  '大久': { lat: 0.003, lng: 0.010 },
  '北方': { lat: 0.008, lng: -0.012 },
  '那久': { lat: -0.003, lng: 0.004 },
  '油井': { lat: -0.008, lng: 0.003 },
  '飯美': { lat: 0.010, lng: 0.005 },
  '飯田': { lat: 0.012, lng: 0.008 },
  '中村': { lat: 0.002, lng: -0.006 },
  '元屋': { lat: -0.004, lng: -0.002 },
  '湊': { lat: 0.006, lng: 0.002 },
  '西村': { lat: -0.002, lng: 0.006 },
};

async function fetchWithProxy(url: string): Promise<string> {
  const errors: string[] = [];
  
  for (const getProxyUrl of CORS_PROXIES) {
    const proxyUrl = getProxyUrl(url);
    try {
      console.log(`Trying proxy: ${proxyUrl.substring(0, 50)}...`);
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout
      
      const response = await fetch(proxyUrl, {
        signal: controller.signal,
        headers: {
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      let text = await response.text();
      
      // Handle allorigins /get endpoint which returns JSON
      if (proxyUrl.includes('/get?')) {
        try {
          const json = JSON.parse(text);
          text = json.contents || text;
        } catch {
          // Not JSON, use as-is
        }
      }
      
      // Verify we got HTML content
      if (text.includes('空き家') || text.includes('recruit.php') || text.includes('<table')) {
        console.log('Successfully fetched HTML content');
        return text;
      } else {
        throw new Error('Response does not appear to contain expected content');
      }
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Unknown error';
      errors.push(`${proxyUrl.substring(0, 30)}: ${errorMsg}`);
      console.warn(`Proxy failed:`, errorMsg);
      continue;
    }
  }
  
  throw new Error(`All proxies failed: ${errors.join('; ')}`);
}

function getCoordinates(district: string, location: string, id: number): { lat: number; lng: number } {
  const base = DISTRICT_COORDS[district] || { lat: 36.21, lng: 133.31 };
  const offset = LOCATION_OFFSETS[location] || { lat: 0, lng: 0 };
  
  // Use property ID to create consistent but varied positions
  const idJitter = {
    lat: ((id * 7) % 100 - 50) * 0.00004,
    lng: ((id * 13) % 100 - 50) * 0.00004,
  };
  
  return {
    lat: base.lat + offset.lat + idJitter.lat,
    lng: base.lng + offset.lng + idJitter.lng,
  };
}

export interface ScrapeResult {
  properties: Property[];
  lastUpdated: string;
  error?: string;
}

// Parse properties from a single page HTML
function parsePageProperties(html: string, seenIds: Set<number>): Property[] {
  const properties: Property[] = [];
  
  // First try text-based parsing since it's more reliable
  // Extract listing codes and their context using regex
  // Pattern: 第R followed by year code and number, like 第R5-51, 第R7-47
  const listingPattern = /第[A-Z]*(\d+)-(\d+)/g;
  const matches = [...html.matchAll(listingPattern)];
  
  // For each listing code found, try to extract the surrounding data
  for (const match of matches) {
    const listingCode = match[0];
    const matchIndex = match.index || 0;
    
    // Generate an ID from the listing code
    const yearPart = parseInt(match[1], 10);
    const numPart = parseInt(match[2], 10);
    const id = yearPart * 100 + numPart;
    
    if (seenIds.has(id)) continue;
    seenIds.add(id);
    
    // Extract context around the listing (about 2000 chars after)
    const context = html.substring(matchIndex, matchIndex + 2000);
    
    // Parse fields from context
    const isNegotiating = context.includes('商談中');
    const hasShop = context.includes('店舗付き');
    const isLand = context.includes('空き地') && !context.includes('空き家');
    const type: Property['type'] = hasShop ? '空き家・店舗付き' : isLand ? '空き地' : '空き家';
    const transactionType: Property['transactionType'] = context.includes('賃貸') ? '賃貸' : '売買';
    
    // Extract district
    let district = '西郷地区（南部）';
    for (const d of Object.keys(DISTRICT_COORDS)) {
      if (context.includes(d)) {
        district = d;
        break;
      }
    }
    
    // Extract location
    let location = '';
    for (const loc of Object.keys(LOCATION_OFFSETS)) {
      if (context.includes(loc)) {
        location = loc;
        break;
      }
    }
    
    // Extract price - handle both sale (万円) and rental (万円/月)
    let priceMan = 0;
    let priceRaw = '価格要問合せ';
    const rentalPriceMatch = context.match(/([\d,]+)\s*万円\s*\/\s*月/);
    const salePriceMatch = context.match(/([\d,]+)\s*万円/);
    
    if (rentalPriceMatch) {
      priceMan = parseInt(rentalPriceMatch[1].replace(/,/g, ''), 10);
      priceRaw = `${rentalPriceMatch[1]}万円/月`;
    } else if (salePriceMatch) {
      priceMan = parseInt(salePriceMatch[1].replace(/,/g, ''), 10);
      priceRaw = `${salePriceMatch[1]}万円`;
    }
    
    // Extract layout
    const layoutMatch = context.match(/(\d+[LDKS]+)/);
    const layout = layoutMatch ? layoutMatch[1] : undefined;
    
    // Extract description (物件ポイント)
    const descMatch = context.match(/物件ポイント[^\n]*\n?\s*([^\n<]+)/);
    const description = descMatch ? descMatch[1].trim() : `${type}物件`;
    
    // Extract contact
    const contactMatch = context.match(/(?:電話番号|TEL)[：:\s]*([\d-]+)/);
    const contact = contactMatch 
      ? `電話番号：${contactMatch[1]}`
      : '隠岐の島町役場　電話番号：08512-2-8570';
    
    // Get coordinates
    const coords = getCoordinates(district, location, id);
    
    // Generate image URL pattern
    const imageUrl = `${BASE_URL}/material/recruit/1/${id}/`;
    
    const property: Property = {
      id,
      listingCode,
      type,
      transactionType,
      isNegotiating,
      district,
      location: location || '西郷',
      priceMan,
      priceRaw,
      layout,
      description,
      contact,
      imageUrl,
      pdfUrl: `${BASE_URL}/cgi-bin/recruit.php/1/detail/${id}`,
      lat: coords.lat,
      lng: coords.lng,
    };
    
    properties.push(property);
  }
  
  return properties;
}

export async function scrapeProperties(): Promise<ScrapeResult> {
  const allProperties: Property[] = [];
  const seenIds = new Set<number>();
  const maxPages = 10; // Safety limit
  
  try {
    console.log('Fetching all listing pages...');
    
    // Fetch all pages
    for (let page = 1; page <= maxPages; page++) {
      const pageUrl = page === 1 ? LISTING_URL : `${LISTING_URL}&page=${page}`;
      console.log(`Fetching page ${page}...`);
      
      try {
        const html = await fetchWithProxy(pageUrl);
        
        const pageProperties = parsePageProperties(html, seenIds);
        console.log(`Found ${pageProperties.length} properties on page ${page}`);
        
        if (pageProperties.length === 0) {
          console.log(`No properties on page ${page}, stopping pagination`);
          break;
        }
        
        allProperties.push(...pageProperties);
        
        // If we got fewer than 20 properties, we've likely reached the last page
        if (pageProperties.length < 20) {
          console.log(`Page ${page} has fewer than 20 properties, assuming last page`);
          break;
        }
        
        // Small delay between requests to be nice to the server
        if (page < maxPages) {
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      } catch (pageError) {
        console.warn(`Failed to fetch page ${page}:`, pageError);
        // If we already have some properties, continue with what we have
        if (allProperties.length > 0) {
          break;
        }
        throw pageError;
      }
    }
    
    console.log(`Total scraped: ${allProperties.length} properties`);
    
    if (allProperties.length === 0) {
      return {
        properties: [],
        lastUpdated: new Date().toISOString(),
        error: 'No properties found - page structure may have changed',
      };
    }
    
    return {
      properties: allProperties,
      lastUpdated: new Date().toISOString(),
    };
  } catch (error) {
    console.error('Scrape error:', error);
    return {
      properties: [],
      lastUpdated: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

// Storage key for cached data
const CACHE_KEY = 'okinoshima-properties-cache';

export interface CachedData {
  properties: Property[];
  lastUpdated: string;
}

export function getCachedProperties(): CachedData | null {
  try {
    const cached = localStorage.getItem(CACHE_KEY);
    if (!cached) return null;
    return JSON.parse(cached);
  } catch {
    return null;
  }
}

export function setCachedProperties(data: CachedData): void {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(data));
  } catch (error) {
    console.warn('Failed to cache properties:', error);
  }
}
